<?php
$conn=mysql_connect('mysql.serversfree.com','u851320107_root','manoj123456');
$db=mysql_select_db('u851320107_hms',$conn);
?>