<?php
include("config1.php");
include("db1.php");
session_start();
$parent_id=$_REQUEST['q'];
$author = $_SESSION['login_username'];
//$author = "kk";
$key='commenttxt'.$parent_id;
echo $key;
$comment_body = mysql_real_escape_string($_POST[$key]);
$q = "INSERT INTO threaded_comments (author, comment, parent_id) VALUES ('$author', '$comment_body', $parent_id)";
$r = mysql_query($q);
mysql_query("UPDATE `feedback` SET `comment_no`=`comment_no`+1 WHERE id='$parent_id'");
if(mysql_affected_rows()==1) {
	header("location:feedback.php");
}
else {
echo "Comment cannot be posted. Please try again.";
}
?>
