<?php
$conn=mysql_connect("localhost","root","") or die("unable to connect");
$db=mysql_select_db("newhc",$conn);
?>
