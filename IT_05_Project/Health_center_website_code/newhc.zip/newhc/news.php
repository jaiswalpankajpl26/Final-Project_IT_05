
<?php
//include('db.php');
include('db1.php');
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
 $sql = 'SELECT * from news';

//mysql_select_db('hospital1');
  $retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
?>
<marquee scrollamount="2" behavior="scroll" direction="up">
   <?
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))

{
       
         
        echo ">><a href='{$row['link']}' target='_blank'>{$row['news']}</a> <br>";
	echo "------------------------------------------------------------------";
	echo "<br>";
}
?>
</marquee>
<?
mysql_close($conn);
?>
<a style="color:black" href='fullnews.php' target='_blank'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;view all</a>
