<?php

$host="127.0.0.1"; // Host name
$username="root"; // Mysql username
$password="manoj"; // Mysql password
$db_name="hospital1"; // Database name
$tbl_name="login"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

// Retrieve data from database
$sql="SELECT * FROM $tbl_name";
$result=mysql_query($sql);
?>

 
<table width="400" border="1" cellspacing="0" cellpadding="3">

 

<?php

// Start looping rows in mysql database.
while($rows=mysql_fetch_array($result)){
?>

<tr>
<td width="10%"><? echo $rows['id']; ?></td>
<td width="30%"><? echo $rows['username']; ?></td>
<td width="30%"><? echo $rows['password']; ?></td>

</tr>

<?php
// close while loop
}

</table>

?>


<?php
// close MySQL connection
mysql_close();
?>
