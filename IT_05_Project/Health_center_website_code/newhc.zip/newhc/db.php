<?php
$conn=mysql_connect("localhost","root","moon123");
$db=mysql_select_db("newhc",$conn);
?>
