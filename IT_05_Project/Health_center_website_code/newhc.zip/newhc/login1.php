<?php
//include('db.php');
include('db1.php');
session_start();
{
    $user=$_POST['username'];
    $pass=$_POST['password'];
    $fetch=mysql_query("SELECT id FROM `login` WHERE
                         username='$user' and password='$pass'");
    $count=mysql_num_rows($fetch);
    if($count!="")
    {
   // session_register("sessionusername");
    $_SESSION['login_username']=$user;
    header("Location:updatedata.php");
    }
    else
    {
       header('Location:index.php');
    }

}
?>
