<?php
$conn=mysql_connect("localhost","root","manoj");
$db=mysql_select_db("hospital1",$conn);
?>
